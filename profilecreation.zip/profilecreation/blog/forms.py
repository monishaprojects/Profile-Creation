from django import forms
from.models import *

class ads(forms.ModelForm):
	class Meta:
		model=UserProfile
		fields=['user','name','email','address']